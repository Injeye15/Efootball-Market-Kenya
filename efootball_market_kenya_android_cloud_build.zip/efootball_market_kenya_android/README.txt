eFootball Market Kenya — Android project starter

WHAT THIS IS
- A native Android wrapper around the HTML marketplace prototype.
- It opens the marketplace in an Android WebView.
- WhatsApp contact links are opened externally.
- It includes the local demo admin UI.

IMPORTANT LIMITATIONS
- This is source code, NOT a compiled APK. This environment does not have the Android SDK/Gradle build toolchain available, so no installable APK has been generated.
- Admin is not secured. Listings are stored in local browser storage on that device only.
- Not ready for public release or Google Play as-is.
- Before public use, add secure admin authentication, remote database/image storage, privacy policy, proper external-link handling, and review applicable KONAMI account-transfer rules.

BUILD APK
1. On a computer, install Android Studio and a compatible JDK.
2. Open this folder in Android Studio.
3. Let Gradle sync; install Android SDK Platform 35 if prompted.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test the APK on a separate Android phone before distributing it.

PHONE-ONLY OPTION
Android Studio generally requires a computer. From a phone, you can use an Android cloud IDE/build service, but review its permissions and never upload signing keys or passwords to untrusted services.
