eFootball Market Kenya — phone-only cloud build guide

This project now includes a GitHub Actions workflow to build a DEBUG APK in the cloud. You do not need a computer, but you do need a GitHub account (you can register using your Gmail address).

PHONE STEPS
1. Download and extract efootball_market_kenya_android_source.zip on your phone. If your phone cannot extract ZIP files, use a trusted file manager that supports ZIP extraction.
2. Open https://github.com in your phone browser and sign in or create a GitHub account using your Gmail address.
3. Create a new repository. Name it efootball-market-kenya. For the simplest upload flow, set it to Private. Do not upload passwords, signing keys, or customer data.
4. Upload the CONTENTS of the extracted project folder into the repository root, keeping folders intact. Make sure the .github/workflows/build-apk.yml file is included. GitHub's mobile website may be awkward for uploading folders; if it will not preserve the folder structure, use GitHub's browser upload on desktop mode or another trusted Git client app.
5. In the repository, open Actions. Select “Build Android APK”, then tap “Run workflow” if it has not started automatically.
6. Wait for the workflow to finish successfully. Open the completed run and find Artifacts. Download “efootball-market-kenya-debug-apk”.
7. Extract the downloaded artifact ZIP to get app-debug.apk. Open it on your Android phone and allow installation from that source only if you trust the build you initiated. You may need to use Settings to allow your browser/file manager to install unknown apps.

IMPORTANT
- This produces a DEBUG/testing APK, not a signed release APK for Google Play.
- GitHub Actions is a third-party service. Only upload the app source, not private credentials.
- The current app is a prototype: admin is not password-protected and listings are stored locally on one device, not synced online. Do not use it for real customer transactions until those issues are fixed.
- Check KONAMI's current terms and applicable Kenyan laws before launching account sales. Never ask sellers or buyers to share passwords or verification codes.
